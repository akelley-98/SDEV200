public class ShapeTest {
    public static void main(String[] args) {
        testShapeCalculation();
    }

    public static void testShapeCalculation() {
        System.out.println("Testing shape calculation...");

        // Create a test shape
        Shape shape = new Rectangle(5, 10);

        // Calculate the area
        double expectedArea = 50;
        double calculatedArea = shape.calculateArea();

        // Check if the calculated area matches the expected area
        if (calculatedArea == expectedArea) {
            System.out.println("Shape calculation test passed!");
        } else {
            System.out.println("Shape calculation test failed!");
        }
    }
}
