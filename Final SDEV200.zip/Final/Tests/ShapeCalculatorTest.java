public class ShapeCalculatorTest {

    public static void main(String[] args) {
        testRectangleAreaCalculation();
        testInvalidInputHandling();
    }

    public static void testRectangleAreaCalculation() {
        System.out.println("Testing rectangle area calculation...");

        // Create a test rectangle
        Rectangle rectangle = new Rectangle(5, 10);

        // Calculate the area
        double expectedArea = 50;
        double calculatedArea = rectangle.calculateArea();

        // Check if the calculated area matches the expected area
        if (calculatedArea == expectedArea) {
            System.out.println("Rectangle area calculation test passed!");
        } else {
            System.out.println("Rectangle area calculation test failed!");
        }
    }

    public static void testInvalidInputHandling() {
        System.out.println("Testing invalid input handling...");

        // Create a test rectangle with invalid input
        Rectangle rectangle = new Rectangle(5, 0);

        // Attempt to calculate the area
        try {
            double calculatedArea = rectangle.calculateArea();
            System.out.println("Invalid input handling test failed! Calculated area: " + calculatedArea);
        } catch (Exception e) {
            System.out.println("Invalid input handling test passed!");
        }
    }
}

