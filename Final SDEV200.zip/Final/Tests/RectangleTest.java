public class RectangleTest {
    public static void main(String[] args) {
        testRectangleAreaCalculation();
    }

    public static void testRectangleAreaCalculation() {
        System.out.println("Testing rectangle area calculation...");

        // Create a test rectangle
        Rectangle rectangle = new Rectangle(5, 10);

        // Calculate the area
        double expectedArea = 50;
        double calculatedArea = rectangle.calculateArea();

        // Check if the calculated area matches the expected area
        if (calculatedArea == expectedArea) {
            System.out.println("Rectangle area calculation test passed!");
        } else {
            System.out.println("Rectangle area calculation test failed!");
        }
    }
}
